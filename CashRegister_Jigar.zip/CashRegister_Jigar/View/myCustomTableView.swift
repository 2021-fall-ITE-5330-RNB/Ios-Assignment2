//  CustomTableView.swift
//  CashRegister_Jigar
//
//  Created by user202348 on 10/25/21.
//  Copyright © 2021 user202348. All rights reserved.

import UIKit
class myCustomTableViewCell: UITableViewCell {
    @IBOutlet weak var itemName: UILabel!
    
    @IBOutlet weak var itemQty: UILabel!
    
    @IBOutlet weak var itemPrice: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}


